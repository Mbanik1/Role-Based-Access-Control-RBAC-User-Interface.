import jwt from "jsonwebtoken";
import Admin from "../../admin/model.js";

async function adminMiddleware(req, res, next) {
  const token = req?.headers?.authorization;
  
  if (!token) {
    return res.status(401).json({ msg: "Token not found" });
  }

  const words = token?.split(" ");

  const jwtToken = words[1];
  if (!jwtToken) {
    return res.status(401).json({ msg: "Unauthorized access" });
  }
  

  


  try {
    
    const decodedValue = jwt.verify(jwtToken, process.env.JWT_SECRET);
    
    if (decodedValue && decodedValue.id) {
    const user= await Admin.findById(decodedValue.id);
    console.log(user);
    if(!user){
        return res.status(400).json({
            success: false,
            msg: "Admin does not exist",
        });
    }
      req.user = user;
      console.log(user);
      next();
    } else {
      res.status(401).send("Unauthorized");
    }
  } catch (err) {
    // console.log(err)
    res.json({
      msg: "Incorrect inputs",
    });
  }
}

export default adminMiddleware;
