import jwt from "jsonwebtoken";
import User from "../../user/model.js";

async function userMiddleware(req, res, next) {
  const token = req?.headers?.authorization;
  if (!token) {
    return res.status(401).json({ msg: "Token not found" });
  }
  const words = token?.split(" ");

  const jwtToken = words[1];
  if (!jwtToken) {
    return res.status(401).json({ msg: "Unauthorized access" });
  }

  const decodedValue = jwt.verify(jwtToken, process.env.JWT_SECRET);
  console.log(decodedValue);
  try {
    
    if (decodedValue && decodedValue.id) {
    const user= await User.findById(decodedValue.id);
    if(!user){
        return res.status(400).json({
            success: false,
            msg: "user does not exist",
        });
    }
      req.user = user;
      next();
    } else {
      res.status(401).send("Unauthorized");
    }
  } catch (err) {
    console.log(err)
    res.json({
      msg: "Incorrect inputs",
    });
  }
}

export default userMiddleware;
