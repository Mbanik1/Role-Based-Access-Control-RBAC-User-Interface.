import express from 'express';
import {register, login, forgotPassword, resetPassword, getProfile, changePassword, getAllActiveMembers, deleteMember, updateMember} from "./controllers.js"
import adminMiddleware from "../middlewares/authMiddlewares/admin.js";
import verifyRole from '../middlewares/authMiddlewares/role.js';

 
const router = express.Router();
 
router.post('/register', adminMiddleware, verifyRole(['admin']), register);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);
router.get('/profile', adminMiddleware, getProfile);
router.post('/change-password', adminMiddleware, changePassword);
router.get('/get-all', adminMiddleware, verifyRole(['admin']), getAllActiveMembers);
router.patch('/delete/:id', adminMiddleware, verifyRole(['admin']), deleteMember);
router.patch('/update/:id', adminMiddleware, verifyRole(['admin']), updateMember);
export default router;