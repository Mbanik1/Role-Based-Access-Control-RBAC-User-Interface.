import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const adminSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  password: { type: String, required: true },
  avatar: { type: String, optional: true },
  isDeleted: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true },
  role: { type: String, enum: ['cook', 'admin', 'accounts', 'waiter'], default: 'admin' },
  otp: String,
  otpExpire: Date,
}, {
  timestamps: true,
});

// Password hash middleware
adminSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    try {
      const salt = await bcrypt.genSalt(10);
      this.password = await bcrypt.hash(this.password, salt);
    } catch (error) {
      return next(error);
    }
  }

  if (this.isModified("otp") && this.otp) {
    try {
      const salt = await bcrypt.genSalt(10);
      this.otp = await bcrypt.hash(this.otp, salt);
    } catch (error) {
      return next(error);
    }
  }

  next();
});

// Method to compare passwords
adminSchema.methods.comparePassword = async function (password) {
  return bcrypt.compare(password, this.password);
};

// Method to compare OTP
adminSchema.methods.compareOtp = async function (otp) {
  return bcrypt.compare(otp, this.otp);
};

export default mongoose.model("Admin", adminSchema);
