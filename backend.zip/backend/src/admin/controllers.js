import jwt from "jsonwebtoken";
import Admin from "./model.js";
import { z } from "zod";
import nodemailer from "nodemailer";
import { registerSchema, loginSchema } from "../middlewares/inputValidation.js";

export const register = async (req, res) => {
  try {
    const { name, email, password, role } = registerSchema.parse(req.body);

    let admin = await Admin.findOne({ email });
    if (admin) {
      return res.status(400).json({ message: "This mail already exists" });
    }

    admin = new Admin({ name, email, password,role });
    await admin.save();

    const token = jwt.sign({ id: admin._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.status(201).json({
      token,
      admin: { id: admin._id, name: admin.name, email: admin.email, role : admin.role },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: error.errors[0]?.message || "Validation error",
      });
    }

    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const login = async (req, res) => {
  try {
    const { email, password } = loginSchema.parse(req.body);

    const admin = await Admin.findOne({ email });
    if (!admin) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await admin.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ id: admin._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.status(200).json({
      token,
      admin: { id: admin._id, name: admin.name, email: admin.email,role: admin.role },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: error.errors[0]?.message || "Validation error",
      });
    }

    console.log(error);
    res.status(500).json({ message: "internal server error" });
  }
};

export const forgotPassword = async (req, res)=>
{
  try{
    const {email} = req.body;

    //find by email
    const admin = await Admin.findOne({email});
    if(!admin){
      return res.status(400).json({message : "No account with that email exists"});
    }
    //Generate an OTP
    // const otp = Math.floor(100000 + Math.random() * 900000);
    const otp ="000000";
    const otpExpire = Date.now() + 10 * 60 * 1000;

    admin.otp = otp;
    admin.otpExpire = otpExpire;
    await admin.save();

    const transporter = nodemailer.createTransport({
      service: 'Gmail', // or any other email service
      auth: {
        user:  "crezytechy@gmail.com",
        pass: "vvmyhpfkiyxgakld",
      },
    });

    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: admin.email,
      subject: "Password reset OTP",
      text: `Your password reset OTP is: ${otp}. It will expire in 10 minutes.`,
    });
    res.status(200).json({ message: "OTP sent to email" });
  }
  catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const resetPassword = async (req, res) => {
  try {
    const { email, otp, password } = req.body;

    // Find admin by email and OTP
    const admin = await Admin.findOne({
      email,
      otpExpire: { $gt: Date.now() }, // Check if OTP is still valid
    });

    if (!admin) {
      return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    
    console.log(otp)

    const isMatch = admin.compareOtp(otp);

    if (!isMatch) {
      return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    console.log(isMatch)

    // Update the password
    admin.password = password;
    admin.otp = undefined;
    admin.otpExpire = undefined;
    await admin.save();

    // Create a JWT token
    const token = jwt.sign({ id: admin.id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.status(200).json({
      token,
      admin: { id: admin.id, name: admin.name, email: admin.email },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const getProfile = async (req, res) => {
  
  try{
    const user = req.user;
    user.password = undefined;
    user.otp = undefined;
    user.otpExpire = undefined;
    res.status(200).json({
      success: true,
      user,});
     
  }
  catch(error){
    return res.status(500).json({
      success: false,
      msg: "Internal server error",
    });
  }
};

// export const getAllActiveMembers= async (req, res) => {
//   try {
//     const users = await Admin.find({});
//     res.status(200).json({users});
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Internal Server Error" });
//   }
// };
export const getAllActiveMembers = async (req, res) => {
  try {
    const { page = 1, name, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;

    // Set up the filter based on the search name
    const filter = { isDeleted: false };
    if (name) {
      filter.name = { $regex: name, $options: "i" }; // case-insensitive search
    }

    // Set up sorting
    const sortCriteria = {};
    sortCriteria[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Set up pagination
    const limit = 5;
    const currentPage = parseInt(page);
    const skip = (currentPage - 1) * limit;

    // Fetch total count of matching users
    const totalUsers = await Admin.countDocuments(filter);

    // Fetch users with pagination
    const users = await Admin.find(filter)
      .sort(sortCriteria)
      .skip(skip)
      .limit(limit);

    // Calculate total pages
    const totalPages = Math.ceil(totalUsers / limit);

    // Respond with pagination details
    res.status(200).json({
      users,
      pagination: {
        totalUsers,
        totalPages,
        currentPage,
        pageSize: limit,
        hasNextPage: currentPage < totalPages,
        hasPrevPage: currentPage > 1,
      },
    });
  } catch (error) {
    console.error("Get Active Members Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const adminId = req.userId;

    const admin = await Admin.findById(adminId);
    if (!admin) {
      return res.status(404).json({ message: "Admin not found" });
    }

    const isMatch = await admin.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }

    admin.password = newPassword;
    await admin.save();

    res.status(200).json({ message: "Password changed successfully" });
  } catch (error) {
    console.error("Change Password Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const deleteMember = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedMember = await Admin.findByIdAndUpdate(
      id,
      { isDeleted: true },
      { new: true }
    );
    if (!deletedMember) {
      return res.status(404).json({ message: "Member not found" });
    }
    res.status(200).json(deletedMember);
  } catch (error) {
    console.error("Delete Member Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
    
  }
}

export const updateMember = async(req,res)=>
{
  try {
    const { id } = req.params;
    const { name, email, role } = req.body;
    const updatedMember = await Admin.findByIdAndUpdate(
      id,
      { name, email, role },
      { new: true }
    );
    if (!updatedMember) {
      return res.status(404).json({ message: "Member not found" });
    }
    res.status(200).json(updatedMember);

    
  } catch (error) {
    console.error("Update Member Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
}