//import things here

import crypto from "crypto";
import twilio from "twilio";
import dotenv from "dotenv";
import mongoose from "mongoose";
// import { Order } from "./model.js";
import { Menu } from "../menu/model.js";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import Razorpay from "razorpay";

// const razorpay = new Razorpay({
//   key_id: process.env.RAZORPAY_KEY_ID,
//   key_secret: process.env.RAZORPAY_KEY_SECRET,
// });

export const placeOrder = async (req, res) => {
  try {
    const { userId, items, paymentMethod, totalPrice } = req.body;

    // Generate Delivery Token
    const deliveryToken = Math.random().toString(36).substr(2);
    
    console.log(deliveryToken);

    const newOrder = new Order({
      userId,
      items,
      paymentMethod,
      totalPrice,
      // otp,
      deliveryToken,
    });

    await newOrder.save();

    // Send OTP via SMS or Email (implement this)
    // await sendOtp(userId, otp);

    res.status(201).json(newOrder);
  } catch (error) {
    console.error("Place Order Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const getPlacedOrders = async (req, res) => {
  try{
    const orders = await Order.find({status: "placed"}).sort({createdAt: -1});
    res.status(200).json(orders);

  }catch(error){
    console.error("Get Placed Order Error:", error);
    res.status(500).json({message: "Internal Server Error"});
  }
}

export const getPreparedOrders = async (req, res) => {
  try{
    const orders = await Order.findOne({status: "prepared"}).sort({createdAt: -1});
    res.status(200).json(orders);

  }catch(error){
    console.error("Get Placed Order Error:", error);
    res.status(500).json({message: "Internal Server Error"});
  }
}

export const getDeliveredOrders = async (req, res) => {
  try{
    const orders = await Order.findOne({status: "delivered"}).sort({createdAt: -1});
    res.status(200).json(orders);

  }catch(error){
    console.error("Get Placed Order Error:", error);
    res.status(500).json({message: "Internal Server Error"});
  }
}

 export const generateKOT = async (req, res) => {
    try {
      const { orderId } = req.body;
  
      const order = await Order.findById(orderId);
  
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
  
      order.status = "prepared";
      await order.save();
  
      res.status(200).json({ message: "KOT generated successfully" });
    } catch (error) {
      console.error("Generate KOT Error:", error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  };
  
  export const generateDelivery = async (req, res) => {
    try {
      const { orderId } = req.body;
  
      const order = await Order.findById(orderId);
  
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
  
      order.status = "delivered";
      await order.save();
  
      res.status(200).json({ message: "Delivery delivered successfully" });
    } catch (error) {
      console.error("Delivered delivery Error:", error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  };

/*
export const handleOnlinePayment = async (req, res) => {
    try {
      const { orderId, paymentId } = req.body;
  
      // Verify payment with Razorpay or other gateway
      const isPaymentValid = await verifyPayment(paymentId); // Implement this function
  
      if (!isPaymentValid) {
        return res.status(400).json({ message: "Invalid payment" });
      }
  
      const order = await Order.findById(orderId);
  
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
  
      order.paymentStatus = "Paid";
      await order.save();
  
      res.status(200).json({ message: "Payment successful", order });
    } catch (error) {
      console.error("Handle Online Payment Error:", error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  };
  
  // For cash payment, update payment status manually
  export const updatePaymentStatus = async (req, res) => {
    try {
      const { orderId } = req.body;
  
      const order = await Order.findById(orderId);
  
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
  
      order.paymentStatus = "Paid";
      await order.save();
  
      res.status(200).json({ message: "Payment status updated", order });
    } catch (error) {
      console.error("Update Payment Status Error:", error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  };
  
  
*/

//DIFFERENT CODE FOR PAYMENT GATEWAY
/*
export const handleOnlinePayment = async (req, res) => {
  const { items } = req.body;

  try {
      const itemIds = items.map((item) => item.menuItem);

      // Fetch the menu items from the database
      const menuItems = await Menu.find({ _id: { $in: itemIds } });

      let totalPrice = 0;
      menuItems.forEach((menuItem) => {
          const orderItem = items.find(
              (item) => item.menuItem.toString() === menuItem._id.toString()
          );
          if (orderItem) {
              totalPrice += parseInt(menuItem.price) * orderItem.quantity;
          }
      });

      const options = {
          amount: Number(totalPrice) * 100, // Amount in paise
          currency: "INR",
          receipt: `receipt_${Date.now()}`, // Unique receipt ID
      };

      const razorpayOrder = await razorpay.orders.create(options);

      res.json({ success: true, order: razorpayOrder });
  } catch (error) {
      console.error("Checkout Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
  }
};

export const updatePaymentStatus = async (req, res) => {
  const { razorpay_order_id, razorpay_signature, razorpay_payment_id } = req.body;
  const { userId, items } = req.query;

  const orderItems = JSON.parse(items);

  let body = `${razorpay_order_id}|${razorpay_payment_id}`;
  const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body.toString())
      .digest("hex");

  const isAuthentic = expectedSignature === razorpay_signature;

  if (isAuthentic) {
      const otp = Math.floor(Math.random() * 9000) + 1000;

      const itemIds = orderItems.map((item) => item.menuItem);
      const menuItems = await Menu.find({ _id: { $in: itemIds } });

      let totalPrice = 0;
      const orderItemsWithDetails = [];

      menuItems.forEach((menuItem) => {
          const orderItem = orderItems.find(
              (item) => item.menuItem.toString() === menuItem._id.toString()
          );
          if (orderItem) {
              orderItemsWithDetails.push({
                  menuItem: menuItem._id,
                  quantity: orderItem.quantity,
              });
              totalPrice += parseInt(menuItem.price) * orderItem.quantity;
          }
      });

      const newOrder = new Order({
          userId,
          items: orderItemsWithDetails,
          totalPrice,
          paymentStatus: "Paid",
          paymentMethod: "Online",
          deliveryToken: otp.toString(),
      });

      await newOrder.save();

      res.redirect(`http://localhost:3000/payment/success?paymentId=${razorpay_payment_id}&otp=${otp}`);
  } else {
      res.redirect(`http://localhost:3000/payment/failed?redirect=true`);
  }
};

*/

export const verifyDeliveryToken = async (req, res) => {
  try {
    const { orderId, deliveryToken } = req.body;

    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    const isMatch = order.compareDeliveryToken(deliveryToken);

    if(!isMatch)
    {
      return res.status(400).json({ message: "Invalid Delivery Token" });
    }
    console.log(isMatch);
    order.deliveryToken = undefined;
    await order.save();

    res.status(200).json({ message: "Delivery token verified successfully" });
  } catch (error) {
    console.error("Verify Delivery Token Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

  export const getOrderHistory = async (req, res) => {
    try {
      const { userId } = req.params;
  
      const orders = await Order.find({ userId, isDeleted: false }).sort({ createdAt: -1 });
  
      res.status(200).json(orders);
    } catch (error) {
      console.error("Get Order History Error:", error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  };
  
