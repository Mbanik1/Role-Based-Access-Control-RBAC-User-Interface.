import express from 'express';
import {
  placeOrder,
  // verifyOtp,
  generateKOT,
  getPlacedOrders,
  getPreparedOrders,
  getDeliveredOrders,
  generateDelivery,
  // handleOnlinePayment,
  // updatePaymentStatus,
  verifyDeliveryToken,
  // updateStatusWaiter,
  getOrderHistory
} from './controllers.js';
import  verifyRole  from '../middlewares/authMiddlewares/role.js';
import adminMiddleware from '../middlewares/authMiddlewares/admin.js';

const router = express.Router();

router.post('/place-orders', placeOrder);

router.get("/get-placed-orders", adminMiddleware ,verifyRole(['admin','cook']) , getPlacedOrders);
router.get("/get-prepared-orders", adminMiddleware ,verifyRole(['admin','waiter']) , getPreparedOrders);
router.get("/get-delivered-orders", adminMiddleware ,verifyRole(['admin','accounts']) , getDeliveredOrders);

router.post('/generate-kot',adminMiddleware ,verifyRole(['admin','cook']), generateKOT);
router.post('/generate-delivery',adminMiddleware ,verifyRole(['admin','waiter']) , generateDelivery);

router.get('/history/:userId', getOrderHistory);

// router.post('/online-payment', handleOnlinePayment);
// router.post('/update-payment-status', updatePaymentStatus);
router.post('/verify-delivery-token', verifyDeliveryToken);

export default router;
