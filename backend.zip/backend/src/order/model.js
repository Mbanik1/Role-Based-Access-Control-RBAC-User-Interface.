import bcrypt from "bcrypt";
import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [
    {
      menuItem: { type: mongoose.Schema.Types.ObjectId, ref: "Menu", required: true },
      quantity: { type: Number, required: true },
    },
  ],
  status: { type: String, enum: ['placed', 'prepared', 'delivered'], required: true,default:'placed' },
  paymentStatus: { type: String, enum: ["Pending", "Paid"], default: "Pending" },
  paymentMethod: { type: String, enum: ["Cash", "Online"], required: true, default: "Cash" },
  totalPrice: { type: Number, required: true },
  deliveryToken: { type: String },
  isDeleted: { type: Boolean, default: false },
}, { timestamps: true });


orderSchema.pre("save", async function (next) {
  if (this.isModified("deliveryToken") && this.deliveryToken) {
    try {
      const salt = await bcrypt.genSalt(10);
      this.deliveryToken = await bcrypt.hash(this.deliveryToken, salt);
    } catch (error) {
      return next(error);
    }
  }

  next();
});

orderSchema.methods.compareDeliveryToken = async function (deliveryToken) {
  return bcrypt.compare(deliveryToken, this.deliveryToken);
};

export const Order = mongoose.model('Order', orderSchema);