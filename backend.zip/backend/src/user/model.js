import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const userSchema = new mongoose.Schema(
  {
    phone: { type: String, required: true, unique: true },
    otp: String,
    otpExpire: Date,
    // orders: [{ type: Schema.Types.ObjectId, ref: "Order" }],
  },
  { timestamps: true }
);

userSchema.pre("save", async function (next) {
  if (this.isModified("otp") && this.otp) {
    try {
      const salt = await bcrypt.genSalt(10);
      this.otp = await bcrypt.hash(this.otp, salt);
    } catch (error) {
      return next(error);
    }
  }

  next();
});

// Method to compare OTP
userSchema.methods.compareOtp = async function (otp) {
  return bcrypt.compare(otp, this.otp);
};



export default mongoose.model("User", userSchema);
