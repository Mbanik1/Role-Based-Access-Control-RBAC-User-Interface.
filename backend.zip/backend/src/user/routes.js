import express from "express";
import { sendOtp,
    verifyOtp
    // getUserOrders 
} from "./controllers.js";
import userMiddleware from "../middlewares/authMiddlewares/user.js"

const router = express.Router();

router.post("/send-otp", sendOtp);
router.post('/verify-otp', verifyOtp);

// router.get('/orders', authenticate, getUserOrders);

export default router;
