import crypto from "crypto";
import twilio from "twilio";
import dotenv from "dotenv";
import mongoose from "mongoose";
import User from "./model.js";
import jwt from "jsonwebtoken";

dotenv.config();

const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// Generate OTP
const generateOtp = () => {
  return "000000"; // Generates a 6-digit OTP
};

// Send OTP via SMS
export const sendOtp = async (req, res) => {
  const { phone } = req.body;
  if (!phone) {
    return res.status(400).send("Phone number is required");
  }

  const otp = generateOtp();

  try {
    await twilioClient.messages.create({
      body: `Your OTP is ${otp}`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phone,
    });

    //Find phone
    const otpExpire= Date.now() + 10 * 60 * 1000;
    const user = await User.findOne({ phone });
    if (user) {
      user.otp = otp;
      user.otpExpire = otpExpire;
      await user.save();
    } else {
      const newUser = new User({ phone, otp, otpExpire: otpExpire });
      await newUser.save();
    }

    res.status(200).send("OTP sent successfully");
  } catch (error) {
    console.error("Error sending OTP:", error);
    res.status(500).send("Failed to send OTP");
  }
};

// Verify OTP and Authenticate User
export const verifyOtp = async (req, res) => {
  try {
    const { phone, otp } = req.body;
    if (!phone && !otp) {
      return res.status(400).send("Phone number and OTP are required");
    }

    const user = await User.findOne({
      phone,
      otpExpire: { $gt: new Date() }, // Check if OTP is still valid
    });

    console.log(user)

    if (!user) {
      return res.status(404).json({ message: "Invalid or expired OTP" });
    }

    const isMatch = user.compareOtp(otp);

    if(!isMatch)
    {
      return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    console.log(isMatch);
    user.otp = undefined;
    user.otpExpire = undefined;
    await user.save();

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.status(200).json({
      token,
      user: { id: user._id, phone: user.phone },
    });

   } catch (error) {
    console.error("Error verifying OTP:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// Get User Orders
export const getUserOrders = async (req, res) => {
  const { phone } = req.user;
  try {
    const user = await User.findOne({ phone });
    if (!user) {
      return res.status(404).send('User not found');
    }
    res.status(200).json({ orders: user.orders });
  } catch (error) {
    console.error('Error fetching user orders:', error);
    res.status(500).send('Failed to fetch user orders');
  }
};

// export { otpStore, sessionStore };
