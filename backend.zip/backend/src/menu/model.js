import mongoose from "mongoose";

const {Schema}=mongoose;

const categorySchema = new Schema({
    name : { type : String, required : true}, 
    isDeleted : { type : Boolean, default : false}
},{timestamps : true})

const menuSchema = new Schema({
    name : { type : String, required : true},
    description : { type : String, required : true},
    price : { type : Number, required : true},
    image : { type : String, required : false}, //Make it true
    categoryId: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
    type : { type : String, required : true},
    size : { type : String, required : true},
    availability : { type : String, required : true},
    isDeleted : { type : Boolean, default : false}

},{
    timestamps : true
})

export const Category = mongoose.model('Category', categorySchema);
export const Menu = mongoose.model('Menu', menuSchema);