import { Menu, Category } from "./model.js"; // Adjust the path as needed

export const createCategory = async (req, res) => {
  try {
    const { name } = req.body;
    const existingCategory = await Category.findOne({ name, isDeleted: false });
    if (existingCategory) {
      return res.status(400).json({ message: "Category already exists" });
    }
    const newCategory = new Category({
      name,
    });
    await newCategory.save();
    res.status(201).json(newCategory);
  } catch (error) {
    console.error("Create Category Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    const existingCategory = await Category.findOne({ name, isDeleted: false });
    if (existingCategory) {
      return res.status(400).json({ message: "Category already exists" });
    }
    const updatedCategory = await Category.findByIdAndUpdate(
      id,
      { name },
      { new: true }
    );

    if (!updatedCategory) {
      return res.status(404).json({ message: "Category not found" });
    }
    res.status(200).json(updatedCategory);
  } catch (error) {
    console.error("Update Category Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedCategory = await Category.findByIdAndUpdate(
      id,
      { isDeleted: true },
      { new: true }
    );

    if (!deletedCategory) {
      return res.status(404).json({ message: "Category not found" });
    }
    res.status(200).json(deletedCategory);
  } catch (error) {
    console.error("Delete Category Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const getCategory = async (req, res) => {
  try {
    const { page = 1, name, sortBy, sortOrder } = req.query;

    // Set up the filter based on the search name
    const filter = { isDeleted: false };
    if (name) {
      filter.name = { $regex: name, $options: "i" }; // case-insensitive search
    }

    // Set up sorting
    const sortCriteria = {};
    if (sortBy) {
      sortCriteria[sortBy] = sortOrder === 'desc' ? -1 : 1;
    } else {
      sortCriteria.createdAt = -1; // default sort by createdAt descending
    }

    // Set up pagination
    const limit = 5;
    const currentPage = parseInt(page);
    const skip = (currentPage - 1) * limit;

    // Fetch total count of matching categories
    const totalCategories = await Category.countDocuments(filter);

    // Fetch categories with pagination
    const categories = await Category.find(filter)
      .sort(sortCriteria)
      .skip(skip)
      .limit(limit);

    // Calculate total pages
    const totalPages = Math.ceil(totalCategories / limit);

    // Respond with pagination details
    res.status(200).json({
      categories,
      pagination: {
        totalCategories,
        totalPages,
        currentPage,
        pageSize: limit,
        hasNextPage: currentPage < totalPages,
        hasPrevPage: currentPage > 1,
      },
    });
  } catch (error) {
    console.error("Get Category Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const createMenuItem = async (req, res) => {
  try {
    const { name, description, price, categoryId, type, size, availability } =
      req.body;

    const category = await Category.findById(categoryId);
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }

    const newItem = new Menu({
      name,
      description,
      price,
      // image,
      categoryId,
      type,
      size,
      availability,
    });

    await newItem.save();

    res.status(201).json(newItem);
  } catch (error) {
    console.error("Create Menu Item Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const updateMenuItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, price, categoryId, type, size, availability } =
      req.body;
    const updatedItem = await Menu.findByIdAndUpdate(
      id,
      { name, description, price, categoryId, type, size, availability },
      { new: true }
    );
    if (!updatedItem) {
      return res.status(404).json({ message: "Menu Item not found" });
    }
    res.status(200).json(updatedItem);
  } catch (error) {
    console.error("Update Menu Item Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const deleteMenuItem = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedItem = await Menu.findByIdAndUpdate(
      id,
      { isDeleted: true },
      { new: true }
    );
    if (!deletedItem) {
      return res.status(404).json({ message: "Menu Item not found" });
    }
    res.status(200).json(deletedItem);
  } catch (error) {
    console.error("Delete Menu Item Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const getMenuItem = async (req, res) => {
  try {
    const { search, category, type, size, availability, sortBy, order, page, limit } = req.query;

    const query = { isDeleted: false };

    // Search
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
        // { price: { $regex: search, $options: "i" } },
        // { categoryId: { $regex: search, $options: "i" } },
        { type: { $regex: search, $options: "i" } },
        { size: { $regex: search, $options: "i" } },
        { availability: { $regex: search, $options: "i" } }
      ];
    }

    // Filtering
    if (category) query.categoryId = category;
    if (type) query.type = type;
    if (size) query.size = size;
    if (availability !== undefined) query.availability = availability === 'true';

    // Sorting
    const sortCriteria = {};
    if (sortBy) {
      sortCriteria[sortBy] = order === 'desc' ? -1 : 1;
    }

    // Pagination
    const pageNumber = parseInt(page) || 1;
    const pageSize = parseInt(limit) || 10;
    const skip = (pageNumber - 1) * pageSize;

    const totalItems = await Menu.countDocuments(query);
    const totalPages = Math.ceil(totalItems / pageSize);

    const menuItems = await Menu.find(query)
      .sort(sortCriteria)
      .skip(skip)
      .limit(pageSize)
      .populate('categoryId', 'name'); // Assuming you want to populate the category name

    res.status(200).json({
      page: pageNumber,
      totalPages,
      totalItems,
      items: menuItems
    });
  } catch (error) {
    console.error("Get Menu Items Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


