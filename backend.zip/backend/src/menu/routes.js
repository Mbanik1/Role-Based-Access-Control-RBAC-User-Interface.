import express from "express";
import adminMiddleware from "../middlewares/authMiddlewares/admin.js";
import verifyRole from "../middlewares/authMiddlewares/role.js";
import {
  createCategory,
  createMenuItem,
  deleteCategory,
  deleteMenuItem,
  getCategory,
  getMenuItem,
  updateCategory,
  updateMenuItem,
} from "./controllers.js";

const router = express.Router();

router.post(
  "/create-category",
  adminMiddleware,
  verifyRole(["admin"]),
  createCategory
);
router.patch(
  "/update-category/:id",
  adminMiddleware,
  verifyRole(["admin"]),
  updateCategory
);
router.patch(
  "/delete-category/:id",
  adminMiddleware,
  verifyRole(["admin"]),
  deleteCategory
);
router.get("/get-categories", getCategory);

router.post(
  "/create-menuItem",
  adminMiddleware,
  verifyRole(["admin"]),
  createMenuItem
);
router.patch(
  "/update-menuItem/:id",
  adminMiddleware,
  verifyRole(["admin"]),
  updateMenuItem
);
router.patch(
  "/delete-menuItem/:id",
  adminMiddleware,
  verifyRole(["admin"]),
  deleteMenuItem
);
router.get("/get-menuItems", getMenuItem);

export default router;
