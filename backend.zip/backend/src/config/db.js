// import mongoose from "mongoose";

// export default async function dbConnection() {
//     try {
//         mongoose.connect('mongodb://127.0.0.1:27017/rmsystem')
//         console.log('DB is connected')
//     } catch (error) {
//         console.log(error)
//     }
// }

import mongoose from "mongoose";
import dotenv from "dotenv";

dotenv.config();
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Database connected successfully");
  } catch (error) {
    console.log("Error connecting to database", error.message);
  }
};
export default connectDB;
