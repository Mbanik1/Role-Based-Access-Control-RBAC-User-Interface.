## Routes
{localhost/api/v1/user/add}