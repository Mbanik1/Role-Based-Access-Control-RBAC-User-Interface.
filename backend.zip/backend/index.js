
import express from 'express';

import adminRouter from './src/admin/routes.js';
import menuRouter from './src/menu/routes.js';
import userRouter from './src/user/routes.js';
// import orderRouter from './src/order/routes.js';
import cors from 'cors'


import dbConnection from './src/config/db.js';


const app = express();

app.use(cors())
app.use(express.json()); 

app.use('/api/v1/user', userRouter);
app.use('/api/v1/admin', adminRouter);
app.use('/api/v1/menu', menuRouter);
// app.use('/api/v1/order', orderRouter);

dbConnection();
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
