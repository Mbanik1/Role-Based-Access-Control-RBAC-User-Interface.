import { React, useState } from "react";
import { Card, CardHeader, CardBody, CardFooter } from '@chakra-ui/react'
import plus from "../components/Assets/plus (1).png";
import Adddialog from "../components/Waiter-dialog/Adddialog";
import {
  Flex,
  Box,
  FormControl,
  FormLabel,
  Input,
  Checkbox,
  Stack,
  Button,
  Heading,
  Text,
  useColorModeValue,
  Image
} from "@chakra-ui/react";


function Plusbutton() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  return (
    <>
      <Card className="w-full max-w-sm">
        <CardBody style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
          <img
            src={plus}
            alt='Green double couch with wooden legs'
            borderRadius='lg'
            onClick={() => setIsModalOpen(true)}
            className="w-[60%] "

          />

        </CardBody>



      </Card>
      <Adddialog
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      // onAdd={handleAdd}
      />
    </>
  )
}
export default Plusbutton;